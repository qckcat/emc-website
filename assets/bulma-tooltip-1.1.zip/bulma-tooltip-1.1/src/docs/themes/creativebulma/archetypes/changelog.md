---
title: "({{ now.Format "2006-01-02" }})"
subtitle: created on {{ now.Format "2006-01-02" }}
date: {{ .Date }}
weight:
version:
draft: true
---

<!-- Available tags are: added, changed, deprecated, removed, fixed, performance, security -->
- {{< tag added >}} New functionality
